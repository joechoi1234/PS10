
def displaynames(lastn, scores):
  #for i in lastn, scores:
    #print(i)
  #for y in scores:
    #print(y)
  l = len(lastn)
  
  for y in range (0,l,1):
    print(y, " ", lastn[y], " ", scores[y])
  print()
  for x in range (l -1, -1, -1):
    print(lastn[x], scores[x])

lastn = []
scores =[]


def hilow(lastn, scores):
  l = len(lastn)
  hiscore = -1.0
  lowscore = 99999999.99
  for y in range(0,l,1):
    if float(scores[y]) > float(hiscore):
      hiindex = y
      hiscore = scores[y]

    if float(scores[y]) < float(lowscore):
      loindex = y
      lowscore = scores[y]

  print("highest score", lastn[hiindex], scores[hiindex])
  print("lowesst score", lastn[loindex], scores[loindex])

f = open("scores.txt", "r")

lastname = f.readline()

while lastname != "":
  lastn.append(str(lastname).rstrip('\n'))
  s = float(f.readline())
  scores.append(s)
  lastname = f.readline()
f.close()

displaynames(lastn, scores)
hilow(lastn, scores)