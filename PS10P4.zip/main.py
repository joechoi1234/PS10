
def displaynames(lastn, batting):
  #for i in lastn, batting: 
#print(i)
  #for y in batting:
      #print(y)
    
  l = len(lastn)

  for x in range(1,l,1):
    print(x, " ", lastn[x], " ", batting[x])
    
f = open("lnames.txt", "r")

lastname = f.readline()
lastn = []
batting = []

while lastname != "":
  lastn.append(str(lastname).rstrip("\n"))
  b = float(f.readline())
  batting.append(b)
  lastname = f.readline()
  
f.close()

displaynames(lastn, batting)

def seqsearch(lastn, sname):
  l = len(lastn)
  sindex = -1
  for y in range(0,l,1):
    if lastn[y] == sname:
      sindex = y
    
  return sindex

response = input("Do you want to repeatedly run this program?: ")

while response == "Yes": 
  sname = input("Enter last name: ")
  i = seqsearch(lastn, sname)
  if i == -1:
    print(sname, "Not in array")
  else:
    print(lastn[i]," batting average of ", batting[i])
    

  response = input("Do you want to repeatedly run this program?: ")